#include "ofMain.h"
#include "ofApp.h"

//========================================================================
int main( )
{
	ofSetupOpenGL(1440, 800, OF_WINDOW);
	ofRunApp(new ofApp());
}