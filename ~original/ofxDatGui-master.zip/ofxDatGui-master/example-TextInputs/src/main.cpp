#include "ofMain.h"
#include "ofApp.h"

int main( )
{
	ofSetupOpenGL(1000, 800, OF_WINDOW);
	ofRunApp(new ofApp());
}
